package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;

public class ShowModuleController{
    
    @FXML
    private void handleEditModule(ActionEvent event)throws IOException {

    }
}