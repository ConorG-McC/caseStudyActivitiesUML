package globals;

public class Constants {
    public static final String VIEW_PATH = "/views/";
    public static final String CSS_FILE = "/css/style.css";
}
